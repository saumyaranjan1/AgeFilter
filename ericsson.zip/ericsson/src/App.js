import './App.css';

import Tablecomponents from './components/Tablecomponents';

function App() {
  return (
    <div className="App">
      <Tablecomponents></Tablecomponents>
    </div>
  );
}

export default App;

import * as React from 'react';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';
import Typography from '@mui/material/Typography';
import '../App.css';


function Slidersection({ filterValue ,setFilterValue}) {
  // const [value, setvalue] = React.useState([0, 100]);
  const minDistance = 10;
  function handleSliderChange(event, newValue, activeThumb) {
    if (!Array.isArray(newValue)) {
      return;
    }
    if (activeThumb === 0) {
      setFilterValue([Math.min(newValue[0], filterValue[1] - minDistance), filterValue[1]]);
    } else {
      setFilterValue([filterValue[0], Math.max(newValue[1], filterValue[0] + minDistance)]);
    }
  }

  return (
    <Box sx={{ width: 300 }}>
      <div className="margin-left-slider">
        <Typography gutterBottom align="left">Filter By age</Typography>
      </div>
      <div className="margin-left-slider">
      <Slider
        getAriaLabel={() => 'Minimum distance'}
        value={filterValue}
        onChange={handleSliderChange}
        valueLabelDisplay="auto"
        disableSwap
      />
      </div>

    
    </Box>
  );
}
export default Slidersection;

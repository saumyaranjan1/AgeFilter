import * as React from 'react';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';
import Slidersection from './Slidersection'
import useApi from './UseApi'
import '../App.css';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

function createData(
    name,
    calories,
    fat,
    carbs,
    protein,
) {
    return { name, calories, fat, carbs, protein };
}

function Tablecomponents() {

    const [filterValue, setFilterValue] = React.useState([0, 100]);
    const { loading, data } = useApi('https://hapi.fhir.org/baseR4/Patient?_format=json',filterValue)
    const date = new Date();
    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    const currentDate = `${year}-${month}-${day}`;

    if (loading) {
        return <h1>Loading</h1>
    } else {
        return (
            <>
                <Slidersection filterValue={filterValue} setFilterValue={setFilterValue} ></Slidersection>
                <TableContainer component={Paper}  >
                    <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
                        <TableHead>
                            <TableRow>
                                <TableCell>ID</TableCell>
                                <TableCell align="right">NAME</TableCell>
                                <TableCell align="right">Gender</TableCell>
                                <TableCell align="right">BirthDate</TableCell>
                                <TableCell align="right">Address</TableCell>
                                <TableCell align="right">Phone</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data.entry.map((row) => (
                                <TableRow
                                    key={row.resource.id}
                                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                >
                                    <TableCell component="th" scope="row">
                                        {row.resource.id}
                                    </TableCell>
                                    <TableCell align="right">  {row.resource.name ? row.resource.name[0].given : '****'}  </TableCell>
                                    <TableCell align="right">{row.resource.gender}</TableCell>
                                    <TableCell align="right">{row.resource.birthDate ? row.resource.birthDate : currentDate}</TableCell>
                                    <TableCell align="right">{row.resource.address ? row.resource.address[0].city + row.resource.address[0].country + row.resource.address[0].state : null}</TableCell>
                                    <TableCell align="right">{row.resource.telecom ? row.resource.telecom[0].value : null}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </>
        );
    }
}

export default Tablecomponents;
